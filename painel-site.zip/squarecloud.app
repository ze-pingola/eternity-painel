MAIN=index.html
MEMORY=256
VERSION=recommended
DISPLAY_NAME=Eternity Painel
DESCRIPTION=Painel de controle Eternity
WEBSITE=true
SUBDOMAIN=eternity-painel
